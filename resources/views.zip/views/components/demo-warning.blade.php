<div class="alert alert-warning" style="margin: 15px 15px; margin-top: 25px;">
    <p style="font-size:15px;" class="mb-0">Demo resets every 24 hours. Feel free to test all the
        features before
        purchasing, keep in mind that some features are disabled.</p>
    <p class="bold mb-0">Demo PHP Version: {{ phpversion() }} </p>
</div>
