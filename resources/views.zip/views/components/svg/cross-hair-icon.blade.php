<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 7.44365 16.5563 3.75 12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25Z" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 1.875V5.625" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1.875 12H5.625" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 22.125V18.375" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M22.125 12H18.375" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="#767F8C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
