<svg width="{{ $width}}" height="{{ $height}}" viewBox="0 0 48 48" fill="{{ $fill}}" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 24C13 24 17 16 24 16C31 16 35 24 35 24C35 24 31 32 24 32C17 32 13 24 13 24Z" stroke="{{ $stroke}}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
    <path d="M24 27C25.6569 27 27 25.6569 27 24C27 22.3431 25.6569 21 24 21C22.3431 21 21 22.3431 21 24C21 25.6569 22.3431 27 24 27Z" stroke="{{ $stroke}}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>
