&copy; {{ config('app.name') }} {{ date('Y') }} | {{ __('all_rights_reserved') }}
