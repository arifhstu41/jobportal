map.addControl(new mapboxgl.NavigationControl());
