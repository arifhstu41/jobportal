
  <svg width="{{ $width}}" height="{{ $height}}" viewBox="0 0 48 48" fill="{{ $fill}}" xmlns="http://www.w3.org/2000/svg">
    <path d="M15 18H17H33" stroke="{{ $stroke}}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
    <path d="M20 18V16C20 15.4696 20.2107 14.9609 20.5858 14.5858C20.9609 14.2107 21.4696 14 22 14H26C26.5304 14 27.0391 14.2107 27.4142 14.5858C27.7893 14.9609 28 15.4696 28 16V18M31 18V32C31 32.5304 30.7893 33.0391 30.4142 33.4142C30.0391 33.7893 29.5304 34 29 34H19C18.4696 34 17.9609 33.7893 17.5858 33.4142C17.2107 33.0391 17 32.5304 17 32V18H31Z" stroke="{{ $stroke}}"stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
    <path d="M22 23V29" stroke="{{ $stroke}}"stroke="#FF4F4F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
    <path d="M26 23V29" stroke="{{ $stroke}}"stroke="#FF4F4F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>
