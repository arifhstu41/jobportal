<svg width="39" height="38" viewBox="0 0 39 38" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M32.73 10.6875H6.60498C5.94914 10.6875 5.41748 11.2192 5.41748 11.875V30.875C5.41748 31.5308 5.94914 32.0625 6.60498 32.0625H32.73C33.3858 32.0625 33.9175 31.5308 33.9175 30.875V11.875C33.9175 11.2192 33.3858 10.6875 32.73 10.6875Z"
        stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M25.604 10.6875V8.3125C25.604 7.68261 25.3538 7.07852 24.9084 6.63312C24.463 6.18772 23.8589 5.9375 23.229 5.9375H16.104C15.4741 5.9375 14.87 6.18772 14.4246 6.63312C13.9792 7.07852 13.729 7.68261 13.729 8.3125V10.6875"
        stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M33.9177 18.749C29.5867 21.2547 24.6701 22.5704 19.6665 22.5625C14.6638 22.5704 9.74794 21.2552 5.41748 18.7503"
        stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M17.8853 17.8125H21.4478" stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round"
        stroke-linejoin="round" />
</svg>
