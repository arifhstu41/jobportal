<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1.5 20.2484H22.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.4995 20.2484V3.74841C13.4995 3.5495 13.4205 3.35874 13.2798 3.21808C13.1392 3.07743 12.9484 2.99841 12.7495 2.99841H3.74951C3.5506 2.99841 3.35983 3.07743 3.21918 3.21808C3.07853 3.35874 2.99951 3.5495 2.99951 3.74841V20.2484" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M20.9995 20.2484V9.74841C20.9995 9.5495 20.9205 9.35874 20.7798 9.21808C20.6392 9.07743 20.4484 8.99841 20.2495 8.99841H13.4995" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M5.99951 6.74841H8.99951" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M7.49951 12.7484H10.4995" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M5.99951 16.4984H8.99951" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16.4995 16.4984H17.9995" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16.4995 12.7484H17.9995" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
