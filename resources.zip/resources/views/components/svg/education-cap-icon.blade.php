<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0.75 9L12 3L23.25 9L12 15L0.75 9Z" stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
    <path d="M17.625 22.5V12L12 9" stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
    <path
        d="M20.625 10.4004V15.5117C20.6253 15.6735 20.573 15.831 20.476 15.9605C19.8444 16.8009 17.18 19.8754 12 19.8754C6.82004 19.8754 4.15558 16.8009 3.52402 15.9605C3.42699 15.831 3.37469 15.6735 3.375 15.5117V10.4004"
        stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>
