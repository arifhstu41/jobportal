<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8.81738 15.1813L15.1813 8.81738" stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round"
        stroke-linejoin="round" />
    <path
        d="M13.5909 16.7731L10.9392 19.4248C10.0953 20.2685 8.95077 20.7424 7.75743 20.7423C6.56409 20.7422 5.41965 20.2681 4.57583 19.4242C3.73201 18.5804 3.25791 17.436 3.25781 16.2426C3.25771 15.0493 3.73161 13.9048 4.57529 13.0608L7.22694 10.4092"
        stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path
        d="M16.7731 13.5899L19.4248 10.9383C20.2685 10.0943 20.7424 8.94979 20.7423 7.75645C20.7422 6.56311 20.2681 5.41867 19.4243 4.57486C18.5804 3.73104 17.436 3.25694 16.2427 3.25684C15.0493 3.25673 13.9048 3.73064 13.0608 4.57431L10.4092 7.22596"
        stroke="var(--primary-500)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>
