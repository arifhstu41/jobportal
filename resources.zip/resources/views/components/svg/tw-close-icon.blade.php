<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_3397_1460)">
<path d="M9 18C13.9706 18 18 13.9706 18 9C18 4.02944 13.9706 0 9 0C4.02944 0 0 4.02944 0 9C0 13.9706 4.02944 18 9 18Z" fill="white"/>
<path d="M11.9998 6L5.99976 12" stroke="#767F8C" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M5.99976 6L11.9998 12" stroke="#767F8C" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_3397_1460">
<rect width="18" height="18" fill="white"/>
</clipPath>
</defs>
</svg>
