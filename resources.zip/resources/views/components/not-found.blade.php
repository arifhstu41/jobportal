<div class="text-center my-3">
    <x-svg.not-found-icon />
    <p class="mt-4 text-center">{{ __($message) }}</p>
</div>
