@error($name)
<span class="text-danger text-xs" role="alert">
    <strong>{{ $message }}</strong>
</span>
@enderror
