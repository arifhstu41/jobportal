<svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12.5 21C17.4706 21 21.5 16.9706 21.5 12C21.5 7.02944 17.4706 3 12.5 3C7.52944 3 3.5 7.02944 3.5 12C3.5 16.9706 7.52944 21 12.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
<path d="M12.5 15C14.5711 15 16.25 13.3211 16.25 11.25C16.25 9.17893 14.5711 7.5 12.5 7.5C10.4289 7.5 8.75 9.17893 8.75 11.25C8.75 13.3211 10.4289 15 12.5 15Z" stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10"/>
<path d="M6.4812 18.6913C7.04615 17.5806 7.90744 16.6478 8.96973 15.9963C10.032 15.3448 11.2539 15 12.5 15C13.7462 15 14.968 15.3448 16.0303 15.9963C17.0926 16.6478 17.9539 17.5806 18.5189 18.6913" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
