<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.81787 15.1813L15.1818 8.81738" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.5904 16.7731L10.9388 19.4248C10.0948 20.2685 8.95028 20.7424 7.75694 20.7423C6.5636 20.7422 5.41916 20.2681 4.57534 19.4242C3.73152 18.5804 3.25743 17.436 3.25732 16.2426C3.25722 15.0493 3.73112 13.9048 4.5748 13.0608L7.22645 10.4092" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16.7727 13.5899L19.4243 10.9383C20.268 10.0943 20.7419 8.94979 20.7418 7.75645C20.7417 6.56311 20.2676 5.41867 19.4238 4.57486C18.5799 3.73104 17.4355 3.25694 16.2422 3.25684C15.0488 3.25673 13.9043 3.73064 13.0603 4.57431L10.4087 7.22596" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
