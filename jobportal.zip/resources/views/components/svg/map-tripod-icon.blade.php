<svg width="38" height="38" viewBox="0 0 38 38" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.25 27.3125L4.75 29.6875V8.3125L14.25 5.9375" stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M23.75 32.0625L14.25 27.3125V5.9375L23.75 10.6875V32.0625Z" stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M23.75 10.6875L33.25 8.3125V29.6875L23.75 32.0625" stroke="#0A65CC" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
