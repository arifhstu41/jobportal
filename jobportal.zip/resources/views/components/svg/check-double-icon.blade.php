<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M27.75 15.75L11.25 32.25L3 24.0004" stroke="var(--primary-500)" stroke-width="3" stroke-linecap="round"
        stroke-linejoin="round" />
    <path d="M44.9996 15.75L28.4996 32.25L24.1172 27.8678" stroke="var(--primary-500)" stroke-width="3"
        stroke-linecap="round" stroke-linejoin="round" />
</svg>
