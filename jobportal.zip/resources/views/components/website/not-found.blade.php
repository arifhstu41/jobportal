<tr>
    <td colspan="10" class="text-center">
        <x-svg.not-found-icon />
        <p class="mt-4">{{ __('no_data_found') }}</p>
        {{ $slot }}
    </td>
</tr>
