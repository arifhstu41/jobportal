<option {{ $selected ? 'selected':''}} value="{{ $value ? $value:$label }}">
    {{ $label }}
</option>
