<?php

namespace App\Http\Traits;

use App\Models\UserPlan;
use App\Models\Transaction;

trait SocialSettingTrait
{
}
